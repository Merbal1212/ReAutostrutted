# Building Re-Autostrutted

## Prerequisites

| Tool | Version |
|---|---|
| .NET SDK | 6.0+ (for the SDK-style project) |
| KSP | 1.8 – 1.12.x installed |

## Quick build (dotnet CLI)

```powershell
# From the repo root — set your KSP path:
dotnet build Source/ReAutostrutted.csproj `
    -c Release `
    /p:KSPDir="C:\Program Files (x86)\Steam\steamapps\common\Kerbal Space Program"
```

The compiled `ReAutostrutted.dll` is written directly to:

```
GameData/Re-Autostrutted/Plugins/ReAutostrutted.dll
```

## Visual Studio / Rider

1. Open `Source/ReAutostrutted.csproj`.
2. In **Project → Properties → Build**, set the `KSPDir` MSBuild property to your KSP install path (or add it to a `Directory.Build.props` file so it persists across IDE restarts).
3. Build → the DLL lands in `GameData/Re-Autostrutted/Plugins/`.

### Directory.Build.props (optional, keeps your path out of the .csproj)

Create `Source/Directory.Build.props`:

```xml
<Project>
  <PropertyGroup>
    <KSPDir>C:\Program Files (x86)\Steam\steamapps\common\Kerbal Space Program</KSPDir>
  </PropertyGroup>
</Project>
```

## Deploying

After building, copy the entire `GameData/Re-Autostrutted/` folder into your KSP installation's `GameData/` directory.

Or symlink it for rapid iteration:

```powershell
# PowerShell (run as Admin)
New-Item -ItemType Junction `
    -Path  "C:\Program Files (x86)\Steam\steamapps\common\Kerbal Space Program\GameData\Re-Autostrutted" `
    -Target "$PWD\GameData\Re-Autostrutted"
```

## Toolbar icon

The icon lives at `GameData/Re-Autostrutted/Textures/toolbar_icon.png`.  
KSP's `GameDatabase` loads it automatically. If it is missing the mod falls back to a solid blue square.

> **Note**: KSP requires toolbar icons to be **38 × 38 px** PNG files.  
> The generated JPG must be converted to PNG before deploying — see the section below.

### Converting the icon to PNG

```powershell
# Using ImageMagick (if installed):
magick "Textures\toolbar_icon.jpg" -resize 38x38 "GameData\Re-Autostrutted\Textures\toolbar_icon.png"
```

Or use any image editor (GIMP, Photoshop, Paint.NET) to export a 38×38 PNG with transparency.
