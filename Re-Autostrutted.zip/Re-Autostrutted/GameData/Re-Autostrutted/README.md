# Re-Autostrutted

A lightweight KSP utility mod that lets you globally configure autostruts for every part on your vessel — in both the VAB/SPH and during flight — from a single clean toolbar menu.

## Features
- **Stock Toolbar button** — opens a draggable, dark-themed IMGUI window
- **4-mode selector** — Disabled / Root Part / Heaviest Part / Grandparent Part
- **Apply to All** — one click sets every eligible part to the chosen mode
- **Disable All** — strips autostruts from the entire vessel instantly
- Works in **VAB, SPH, and Flight** scenes
- Gracefully handles docking, undocking, and staging events

## Installation
1. Copy the `GameData/Re-Autostrutted/` folder into your KSP `GameData/` directory.
2. Launch KSP — the truss icon will appear in the stock toolbar.

## Compatibility
- KSP **1.8 – 1.12.x**
- No other mods required

## Building from Source
See [BUILD.md](../../BUILD.md) in the repository root.
