// Re-Autostrutted — AutoStrutManager KSP Mod
// A lightweight utility for globally configuring autostruts on all vessel parts.
// Compatible with KSP 1.8+ (Unity 2019 / .NET 3.5 / .NET 4.x)
//
// Build references needed:
//   - <KSP_DIR>/KSP_Data/Managed/Assembly-CSharp.dll
//   - <KSP_DIR>/KSP_Data/Managed/UnityEngine.dll
//   - <KSP_DIR>/KSP_Data/Managed/UnityEngine.CoreModule.dll
//   - <KSP_DIR>/KSP_Data/Managed/UnityEngine.IMGUIModule.dll
//   - <KSP_DIR>/KSP_Data/Managed/UnityEngine.TextRenderingModule.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using KSP.UI.Screens;

namespace ReAutostrutted
{
    /// <summary>
    /// Main KSPAddon — loaded in both the Flight and Editor scenes.
    /// </summary>
    [KSPAddon(KSPAddon.Startup.FlightAndEditor, false)]
    public class AutoStrutManager : MonoBehaviour
    {
        // ──────────────────────────────────────────────────────────────────────
        // Constants & statics
        // ──────────────────────────────────────────────────────────────────────
        private const string MOD_NAME      = "Re-Autostrutted";
        private const string MOD_LOG       = "[Re-Autostrutted]: ";
        private const string TEXTURE_PATH  = "Re-Autostrutted/Textures/toolbar_icon"; // GameData-relative
        private const string WINDOW_TITLE  = "Re-Autostrutted";
        private const int    WINDOW_ID     = 0x52415354; // "RAST" in hex — unique-ish

        // Window layout
        private Rect  _windowRect  = new Rect(200f, 200f, 280f, 260f);
        private bool  _windowVisible = false;
        private bool  _isDragging    = false;

        // Toolbar
        private ApplicationLauncherButton _appButton;
        private Texture2D                 _btnTexture;

        // Autostrut mode selection (mirrors Part.AutoStrutMode)
        private int   _selectedMode = 0; // 0=Off,1=Root,2=Heaviest,3=Grandparent
        private readonly string[] _modeLabels = { "Disabled", "Root Part", "Heaviest Part", "Grandparent Part" };
        // Map index → KSP enum value
        private readonly Part.AutoStrutMode[] _modeValues =
        {
            Part.AutoStrutMode.Off,
            Part.AutoStrutMode.Root,
            Part.AutoStrutMode.Heaviest,
            Part.AutoStrutMode.Grandparent,
        };

        // Status feedback
        private string _statusMessage  = "";
        private float  _statusClearAt  = 0f;
        private const float STATUS_TTL = 3f;

        // GUIStyles (lazily initialised on first OnGUI call)
        private GUIStyle _styleWindow;
        private GUIStyle _styleLabel;
        private GUIStyle _styleLabelSmall;
        private GUIStyle _styleButton;
        private GUIStyle _styleButtonSelected;
        private GUIStyle _styleButtonDanger;
        private GUIStyle _styleButtonApply;
        private GUIStyle _styleStatus;
        private bool     _stylesBuilt = false;

        // ──────────────────────────────────────────────────────────────────────
        // Unity lifecycle
        // ──────────────────────────────────────────────────────────────────────

        private void Awake()
        {
            Log("Awake");
            LoadTexture();
            GameEvents.onGUIApplicationLauncherReady.Add(OnAppLauncherReady);
            GameEvents.onGUIApplicationLauncherDestroyed.Add(OnAppLauncherDestroyed);

            // Gracefully handle scene transitions that mutate the part tree
            GameEvents.onVesselWasModified.Add(OnVesselModified);
            GameEvents.onPartDeCoupleComplete.Add(OnDecouple);
            GameEvents.onDockingComplete.Add(OnDock);
        }

        private void OnDestroy()
        {
            Log("OnDestroy — cleaning up");
            GameEvents.onGUIApplicationLauncherReady.Remove(OnAppLauncherReady);
            GameEvents.onGUIApplicationLauncherDestroyed.Remove(OnAppLauncherDestroyed);
            GameEvents.onVesselWasModified.Remove(OnVesselModified);
            GameEvents.onPartDeCoupleComplete.Remove(OnDecouple);
            GameEvents.onDockingComplete.Remove(OnDock);
            RemoveAppButton();
        }

        private void OnGUI()
        {
            if (!_windowVisible) return;

            if (!_stylesBuilt) BuildStyles();

            GUI.skin = null; // reset to Unity default before we draw our styled window
            _windowRect = GUI.Window(WINDOW_ID, _windowRect, DrawWindow, GUIContent.none, _styleWindow);
        }

        // ──────────────────────────────────────────────────────────────────────
        // Application Launcher
        // ──────────────────────────────────────────────────────────────────────

        private void OnAppLauncherReady()
        {
            if (_appButton != null) return;

            _appButton = ApplicationLauncher.Instance.AddModApplication(
                onTrue:    OnButtonTrue,
                onFalse:   OnButtonFalse,
                onHover:   null,
                onHoverOut: null,
                onEnable:  null,
                onDisable: null,
                visibleInScenes: ApplicationLauncher.AppScenes.FLIGHT |
                                 ApplicationLauncher.AppScenes.VAB    |
                                 ApplicationLauncher.AppScenes.SPH,
                texture: _btnTexture
            );
            Log("App Launcher button added");
        }

        private void OnAppLauncherDestroyed()
        {
            RemoveAppButton();
        }

        private void RemoveAppButton()
        {
            if (_appButton == null) return;
            ApplicationLauncher.Instance?.RemoveModApplication(_appButton);
            _appButton = null;
            Log("App Launcher button removed");
        }

        private void OnButtonTrue()  { _windowVisible = true;  Log("Window opened"); }
        private void OnButtonFalse() { _windowVisible = false; Log("Window closed"); }

        // ──────────────────────────────────────────────────────────────────────
        // Window drawing
        // ──────────────────────────────────────────────────────────────────────

        private void DrawWindow(int id)
        {
            // ── Title bar ──────────────────────────────────────────────────
            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label(WINDOW_TITLE, _styleLabel);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("✕", _styleButton, GUILayout.Width(22), GUILayout.Height(22)))
            {
                CloseWindow();
            }
            GUILayout.EndHorizontal();

            DrawSeparator();

            // ── Mode selector ──────────────────────────────────────────────
            GUILayout.Label("Autostrut Mode", _styleLabelSmall);
            GUILayout.Space(4);

            GUILayout.BeginVertical();
            for (int i = 0; i < _modeLabels.Length; i++)
            {
                bool selected = (_selectedMode == i);
                GUIStyle style = selected ? _styleButtonSelected : _styleButton;
                if (GUILayout.Button(_modeLabels[i], style, GUILayout.ExpandWidth(true), GUILayout.Height(26)))
                {
                    _selectedMode = i;
                }
            }
            GUILayout.EndVertical();

            GUILayout.Space(8);
            DrawSeparator();
            GUILayout.Space(6);

            // ── Action buttons ─────────────────────────────────────────────
            if (GUILayout.Button($"▶  Apply \"{_modeLabels[_selectedMode]}\" to All Parts", _styleButtonApply, GUILayout.Height(30)))
            {
                ApplyModeToAll(_modeValues[_selectedMode]);
            }

            GUILayout.Space(4);

            if (GUILayout.Button("✕  Disable All Autostruts", _styleButtonDanger, GUILayout.Height(26)))
            {
                ApplyModeToAll(Part.AutoStrutMode.Off);
            }

            // ── Status bar ─────────────────────────────────────────────────
            if (!string.IsNullOrEmpty(_statusMessage))
            {
                if (Time.realtimeSinceStartup > _statusClearAt)
                    _statusMessage = "";
                else
                    GUILayout.Label(_statusMessage, _styleStatus);
            }
            else
            {
                GUILayout.Label("", _styleStatus); // keep layout stable
            }

            GUILayout.EndVertical();

            // Allow dragging by title area (top ~24px)
            if (Event.current.type == EventType.MouseDown &&
                new Rect(0, 0, _windowRect.width - 26, 24).Contains(Event.current.mousePosition))
            {
                _isDragging = true;
            }
            if (_isDragging)
            {
                if (Event.current.type == EventType.MouseDrag)
                    _windowRect.position += Event.current.delta;
                if (Event.current.type == EventType.MouseUp)
                    _isDragging = false;
            }

            // Clamp to screen
            _windowRect.x = Mathf.Clamp(_windowRect.x, 0, Screen.width  - _windowRect.width);
            _windowRect.y = Mathf.Clamp(_windowRect.y, 0, Screen.height - _windowRect.height);
        }

        private void DrawSeparator()
        {
            GUILayout.Box("", GUILayout.ExpandWidth(true), GUILayout.Height(1));
        }

        // ──────────────────────────────────────────────────────────────────────
        // Core logic — apply autostrut mode
        // ──────────────────────────────────────────────────────────────────────

        private void ApplyModeToAll(Part.AutoStrutMode mode)
        {
            List<Part> parts = GetVesselParts();
            if (parts == null || parts.Count == 0)
            {
                SetStatus("⚠  No vessel / parts found.");
                return;
            }

            int applied   = 0;
            int skipped   = 0;
            int errored   = 0;

            foreach (Part part in parts)
            {
                if (part == null) { skipped++; continue; }

                try
                {
                    // Skip parts that cannot be autostruted (procedural fairings, etc.)
                    if (!PartIsEligible(part)) { skipped++; continue; }

                    part.autoStrutMode = mode;

                    // Notify KSP that the part's strut config changed so physics refreshes
                    part.UpdateAutoStrut();
                    applied++;
                }
                catch (Exception ex)
                {
                    errored++;
                    Log($"Error setting autostrut on part '{SafePartName(part)}': {ex.Message}");
                }
            }

            string modeLabel = (mode == Part.AutoStrutMode.Off) ? "Disabled" : mode.ToString();
            string msg = $"✓  {modeLabel} applied to {applied} part(s)";
            if (skipped > 0) msg += $", {skipped} skipped";
            if (errored > 0) msg += $", {errored} errors";
            SetStatus(msg);
            Log($"ApplyModeToAll({mode}): {msg}");
        }

        // ──────────────────────────────────────────────────────────────────────
        // Vessel / part helpers
        // ──────────────────────────────────────────────────────────────────────

        private List<Part> GetVesselParts()
        {
            // Editor scene
            if (HighLogic.LoadedSceneIsEditor)
            {
                if (EditorLogic.fetch?.ship?.parts != null)
                    return EditorLogic.fetch.ship.parts;
                return null;
            }

            // Flight scene
            Vessel v = FlightGlobals.ActiveVessel;
            if (v == null || v.parts == null) return null;
            return v.parts;
        }

        private bool PartIsEligible(Part part)
        {
            // Parts with no rigid body are non-physical (e.g. flags, certain fairings).
            // KSP internally skips them for autostruts anyway.
            if (part.rb == null && !HighLogic.LoadedSceneIsEditor) return false;

            // Root part cannot meaningfully be autostruted
            // (KSP already treats it as the anchor but setting the field is harmless;
            //  we include it anyway so the user gets full-vessel coverage)
            return true;
        }

        private string SafePartName(Part p)
        {
            try { return p?.partInfo?.title ?? p?.name ?? "<unknown>"; }
            catch { return "<unknown>"; }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Event handlers
        // ──────────────────────────────────────────────────────────────────────

        private void OnVesselModified(Vessel v)
        {
            // No action needed — next Apply call will re-query the part list.
            Log($"Vessel modified: {v?.vesselName ?? "unknown"}");
        }

        private void OnDecouple(Part p)
        {
            Log($"Part decoupled: {SafePartName(p)} — part list will refresh on next Apply");
        }

        private void OnDock(GameEvents.FromToAction<Part, Part> action)
        {
            Log($"Dock event: {SafePartName(action.from)} ↔ {SafePartName(action.to)}");
        }

        // ──────────────────────────────────────────────────────────────────────
        // Texture loading
        // ──────────────────────────────────────────────────────────────────────

        private void LoadTexture()
        {
            // GameDatabase approach — works at runtime after asset loading
            _btnTexture = GameDatabase.Instance?.GetTexture(TEXTURE_PATH, false);

            if (_btnTexture == null)
            {
                // Fallback: plain coloured square
                Log("Toolbar texture not found via GameDatabase — using fallback colour");
                _btnTexture = MakeSolidTexture(38, 38, new Color(0.22f, 0.60f, 0.88f));
            }
            else
            {
                Log("Toolbar texture loaded");
            }
        }

        private Texture2D MakeSolidTexture(int w, int h, Color c)
        {
            Color[] pix = new Color[w * h];
            for (int i = 0; i < pix.Length; i++) pix[i] = c;
            Texture2D tex = new Texture2D(w, h);
            tex.SetPixels(pix);
            tex.Apply();
            return tex;
        }

        // ──────────────────────────────────────────────────────────────────────
        // UI helpers
        // ──────────────────────────────────────────────────────────────────────

        private void CloseWindow()
        {
            _windowVisible = false;
            _appButton?.SetFalse(makeCall: false);
        }

        private void SetStatus(string msg)
        {
            _statusMessage = msg;
            _statusClearAt = Time.realtimeSinceStartup + STATUS_TTL;
        }

        private static void Log(string msg) => Debug.Log(MOD_LOG + msg);

        // ──────────────────────────────────────────────────────────────────────
        // Styles — built lazily after Unity GUI skin is ready
        // ──────────────────────────────────────────────────────────────────────

        private void BuildStyles()
        {
            // Colours
            Color bgColor     = new Color(0.08f, 0.08f, 0.10f, 0.95f);
            Color accentColor = new Color(0.22f, 0.60f, 0.88f, 1.00f);
            Color dangerColor = new Color(0.80f, 0.20f, 0.20f, 1.00f);
            Color applyColor  = new Color(0.12f, 0.55f, 0.25f, 1.00f);
            Color selectedBg  = new Color(0.20f, 0.50f, 0.80f, 0.85f);
            Color btnBg       = new Color(0.18f, 0.18f, 0.22f, 1.00f);
            Color btnHover    = new Color(0.25f, 0.25f, 0.30f, 1.00f);

            // Window background
            _styleWindow = new GUIStyle(GUI.skin.window);
            _styleWindow.normal.background  = MakeSolidTexture(1, 1, bgColor);
            _styleWindow.focused.background = _styleWindow.normal.background;
            _styleWindow.border = new RectOffset(4, 4, 4, 4);
            _styleWindow.padding = new RectOffset(8, 8, 8, 8);

            // Title label
            _styleLabel = new GUIStyle(GUI.skin.label)
            {
                fontSize  = 13,
                fontStyle = FontStyle.Bold,
            };
            _styleLabel.normal.textColor = Color.white;

            // Section label
            _styleLabelSmall = new GUIStyle(GUI.skin.label)
            {
                fontSize  = 11,
                fontStyle = FontStyle.Normal,
            };
            _styleLabelSmall.normal.textColor = new Color(0.75f, 0.75f, 0.80f);

            // Default button
            _styleButton = new GUIStyle(GUI.skin.button)
            {
                fontSize  = 11,
                alignment = TextAnchor.MiddleLeft,
            };
            _styleButton.normal.background  = MakeSolidTexture(1, 1, btnBg);
            _styleButton.hover.background   = MakeSolidTexture(1, 1, btnHover);
            _styleButton.normal.textColor   = Color.white;
            _styleButton.hover.textColor    = Color.white;
            _styleButton.border             = new RectOffset(3, 3, 3, 3);
            _styleButton.padding            = new RectOffset(8, 8, 4, 4);

            // Selected / active mode button
            _styleButtonSelected = new GUIStyle(_styleButton);
            _styleButtonSelected.normal.background = MakeSolidTexture(1, 1, selectedBg);
            _styleButtonSelected.hover.background  = MakeSolidTexture(1, 1, selectedBg);
            _styleButtonSelected.fontStyle = FontStyle.Bold;
            _styleButtonSelected.normal.textColor = Color.white;

            // "Disable All" danger button
            _styleButtonDanger = new GUIStyle(_styleButton)
            {
                alignment = TextAnchor.MiddleCenter,
            };
            _styleButtonDanger.normal.background = MakeSolidTexture(1, 1, dangerColor);
            _styleButtonDanger.hover.background  = MakeSolidTexture(1, 1, new Color(0.9f, 0.3f, 0.3f));
            _styleButtonDanger.normal.textColor  = Color.white;
            _styleButtonDanger.hover.textColor   = Color.white;

            // "Apply to All" success button
            _styleButtonApply = new GUIStyle(_styleButton)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold,
            };
            _styleButtonApply.normal.background = MakeSolidTexture(1, 1, applyColor);
            _styleButtonApply.hover.background  = MakeSolidTexture(1, 1, new Color(0.15f, 0.65f, 0.30f));
            _styleButtonApply.normal.textColor  = Color.white;
            _styleButtonApply.hover.textColor   = Color.white;

            // Status message
            _styleStatus = new GUIStyle(GUI.skin.label)
            {
                fontSize  = 10,
                wordWrap  = true,
                alignment = TextAnchor.MiddleLeft,
            };
            _styleStatus.normal.textColor = new Color(0.60f, 0.90f, 0.60f);

            _stylesBuilt = true;
        }
    }
}
